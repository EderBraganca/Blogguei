package com.blogguei.blogguei;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloggueiApplicationTests {

	@Test
	void contextLoads() {
	}

}
